# -*- coding: utf-8 -*-
"""
Created on Wed May 17 10:13:52 2023

@author: wp
"""

import streamlit as st 
import numpy as np 
import pandas as pd
import pickle

import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import accuracy_score,confusion_matrix,f1_score

st.markdown("# 模型应用 ❄️")
st.sidebar.markdown("# 模型应用 ❄️")

uploaded_file0 = st.file_uploader("选择本地模型")
uploaded_file = st.file_uploader("选择一个文件")
if (uploaded_file is not None) and (uploaded_file0 is not None):
    pickle_model = pickle.load(uploaded_file0)
    df_new = pd.read_csv(uploaded_file)
#df_new=pd.read_csv(r"F:\notebooks1\streamlit\data\new.csv")
    st.table(df_new.head())

    df_new_copy=df_new.copy()
    df_new_copy.drop(axis=1,columns="Name",inplace=True)
    df_new_copy=pd.get_dummies(df_new_copy,columns=["Gender","Area","Email","Mobile"])
    st.table(df_new_copy.head())
    
    y_pred = pickle_model.predict(df_new_copy.values)
    
    df_new["predict"]=y_pred
    st.table(df_new[["Name","predict"]])

