# -*- coding: utf-8 -*-
"""
Created on Wed May 17 10:13:52 2023

@author: wp
"""

import streamlit as st 
import numpy as np 
import pandas as pd
import pickle

import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from streamlit_echarts import st_echarts

from sklearn.metrics import accuracy_score,confusion_matrix,f1_score

def pivot_bar(data):
    option = {
      "xAxis": {
        "type": 'category',
        "data": data.index.tolist()
      },
      "legend":{},
      "yAxis": {
        "type": 'value'
      },
      "series": [
      ]
    };
    for i in data.columns:
        option["series"].append({"data":data[i].tolist(),"name":i,"type":"bar"})
    return option

st.markdown("# 模型训练 🎈")
st.sidebar.markdown("# 模型训练  🎈")

df=pd.read_csv(r"F:\notebooks1\streamlit\data\old.csv")
st.table(df.head())

st.subheader("透视表分析")
with st.form("透视表"):
    index_val=st.multiselect("选择index",df.columns,["Response"])
    agg_fuc=st.selectbox("选择统计方式",[np.mean,len,np.sum])
    submitted0 = st.form_submit_button("Submit0")
    if submitted0:
        z1=df.pivot_table(index=index_val,aggfunc=agg_fuc)
        st.table(z1)
        st_echarts(pivot_bar(z1))
        


df_copy=df.copy()
df_copy.drop(axis=1,columns="Name",inplace=True)
df_copy["Response"]=df_copy["Response"].map({"no":0,"yes":1})
df_copy=pd.get_dummies(df_copy,columns=["Gender","Area","Email","Mobile"])
st.table(df_copy.head())

y=df_copy["Response"].values
x=df_copy.drop(axis=1,columns="Response").values
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2)

with st.form("参数条件"):
   estimators_val = st.slider("estimators",2,200,10)
   max_depth_val = st.slider("max_depth",1,10,2)
   submitted = st.form_submit_button("Submit")

if 'model' not in st.session_state:
    st.session_state.model = RandomForestClassifier(n_estimators=estimators_val,max_depth=max_depth_val, random_state=1234)

st.session_state.model.fit(X_train, y_train)

y_pred = st.session_state.model.predict(X_test)
st.table(confusion_matrix(y_test, y_pred))
st.write(f1_score(y_test, y_pred))

if st.button("保存模型"):
    pkl_filename = "F:\\pickle_model1.pkl"
    with open(pkl_filename, 'wb') as file:
        pickle.dump(st.session_state.model, file)
    st.write("保存成功")
