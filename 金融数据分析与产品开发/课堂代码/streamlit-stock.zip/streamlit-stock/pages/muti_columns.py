# -*- coding: utf-8 -*-
"""
Created on Wed Feb 22 23:08:25 2023

@author: wp
"""
import akshare as ak
import streamlit as st
from streamlit_echarts import st_echarts
from pyecharts import options as opts
from pyecharts.charts import Kline
from pyecharts.charts import Line
from pyecharts.charts import Bar
from streamlit_echarts import st_pyecharts
import pandas as pd
import numpy as np
import talib
from datetime import datetime
import sys
import main_single_columns


st.markdown("# 多因子 ❄️")
st.sidebar.markdown("# 多因子 ❄️")

sys.path.append(r'F:\notebooks1\streamlit\streamlit-stock')

start=datetime(2018,2,22)
end=datetime(2023,2,10)
stock_list=["003002.SZ","003003.SZ","300001.SZ"]
buy_date={"2020-09-22":["003002.SZ","003003.SZ"]}
sell_date={"2023-02-02":["003002.SZ","003003.SZ"]}
cash_value={}

result=main_single_columns.huice_run_num(start,end,stock_list,main_single_columns.my_strategy_date_2)
st_echarts(main_single_columns.cash_line(cash_value))