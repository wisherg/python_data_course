# -*- coding: utf-8 -*-
"""
Created on Thu May 11 10:04:41 2023

@author: wp
"""
import json
from streamlit_echarts import JsCode
import streamlit as st
from streamlit_echarts import st_echarts
import pandas as pd
import numpy as np
from PIL import Image
from datetime import datetime
import main
import sys
sys.path.append(r'F:\notebooks1\streamlit\streamlit_c_celue')

start=datetime(2018,2,22)
end=datetime(2023,2,10)
stock_daily=st.session_state.stock_daily
cwzbsj=st.session_state.cw

st.subheader("行情因子选择")
col51,col52,col53,col54,col55=st.columns(5)

col_list5=[col51,col52,col53,col54,col55]
#st.write(len(stock_daily.columns))
stock_columns={}
n=0
for i in stock_daily.columns[8:24]:
    with col_list5[n]:
        select0=st.checkbox(i)
        if select0:
            sort_val=st.selectbox(i+"排序方式",[True,False])
            weight_val=st.slider(i+"权重",0.0,2.0,1.0)
            stock_columns.update({i:[sort_val,weight_val]})
    if n==4:
        n=0
    else:
        n=n+1

st.write(stock_columns)


st.subheader("财务因子选择")
col501,col502,col503,col504,col505=st.columns(5)
col_list05=[col501,col502,col503,col504,col505]
cw_columns={}
for i in cwzbsj.isnull().sum().sort_values()[5:120].index:
    with col_list05[n]:
        select0=st.checkbox(i)
        if select0:
            sort_val=st.selectbox(i+"排序方式",[True,False])
            weight_val=st.slider(i+"权重",0.0,2.0,1.0)
            cw_columns.update({i:[sort_val,weight_val]})
    if n==4:
        n=0
    else:
        n=n+1
#st.write(cwzbsj.isnull().sum().sort_values()[5:120])
st.write(cw_columns)

run2=st.button("run2")
if run2:
    
    time_id=pd.Series(stock_daily.date.unique()).sort_values().tolist()
    buy_date={}
    sell_date={}
    postion=set([])
    stock_list=set([])
    #stock_columns={'总市值(万元)':[True,0.9],'市盈率(静态)':[False,1],'换手率(%)':[True,0.3]}
    #stock_columns={'总市值(万元)':[True,0.8],'市盈率(静态)':[False,1]}
    #cw_columns={'营业收入环比增长率(%)(单季度)':[True,0.1]}
    for i in range(0,len(time_id),30):
        stock_list_tem=stock_daily[(stock_daily["date"]==time_id[i+1])&(stock_daily["open"]!=stock_daily["close"])]["股票代码"].unique()
        
        stock_list_tem_0=stock_daily[(stock_daily["date"]==time_id[i])&(stock_daily["股票代码"].isin(stock_list_tem))]
        columns_list=list(stock_columns.keys())
        factor1_stock=stock_list_tem_0.sort_values(by=columns_list[0],ascending=stock_columns[columns_list[0]][0])["股票代码"].tolist()
        f_1_df=pd.Series(range(1,len(factor1_stock)+1),index=factor1_stock)*stock_columns[columns_list[0]][1]
        for j in columns_list[1:]:
            factor1_stock=stock_list_tem_0.sort_values(by=j,ascending=stock_columns[j][0])["股票代码"].tolist()
            f_1_df=f_1_df+pd.Series(range(1,len(factor1_stock)+1),index=factor1_stock)*stock_columns[j][1]
        
        cw_list_tem_0=cwzbsj[(cwzbsj["公告日期"]<time_id[i])&(cwzbsj["股票代码"].isin(stock_list_tem))].groupby("股票代码").last()
        if len(cw_list_tem_0)>0:
            for j in cw_columns.keys():
                factor1_stock=cw_list_tem_0.sort_values(by=j,ascending=cw_columns[j][0]).index.tolist()
                f_1_df=f_1_df+pd.Series(range(1,len(factor1_stock)+1),index=factor1_stock)*cw_columns[j][1]
        
        buy_list=f_1_df.sort_values().head(5).index.tolist()
        buy_date.update({str(time_id[i].date()):buy_list})
        sell_date.update({str(time_id[i].date()):list(postion-set(buy_list))})
        postion=set(buy_list)
        stock_list=stock_list|postion
        
    result=main.huice_run_num(start,end,sell_date,buy_date,stock_list,main.my_strategy_date_2)
    st_echarts(main.line_cash(result))