# -*- coding: utf-8 -*-
"""
Created on Thu May 18 10:15:34 2023

@author: wp
"""
import sqlite3
import pandas as pd  
import talib
from datetime import datetime
import backtrader as bt
import matplotlib.pyplot as plt
import akshare as ak
import numpy as np 
import streamlit as st
from streamlit_echarts import st_echarts
from pylab import mpl

mpl.rcParams['font.sans-serif']=['SimHei']
mpl.rcParams['axes.unicode_minus']=False

@st.cache_data
def read_cw():
    cwzbsj=pd.read_sql("select * from cwzbsj where 股票代码>'003000.SZ'",con=conn)
    cwzbsj["公告日期"]=cwzbsj["公告日期"].str.replace("\.0","").astype("datetime64")
    cwzbsj.set_index("公告日期",inplace=True,drop=False)
    return cwzbsj

@st.cache_data
def read_hq():
    stock_daily=pd.read_sql("select * from stock_daily where 股票代码>'003000.SZ'",con=conn)
    stock_daily.columns=['index', 'date', '股票代码', '股票简称', 'open', 'high', 'low', 'close', 'volume',
           '成交额(千元)', '换手率(%)', '量比', '市盈率(静态)', '市盈率(TTM)', '市盈率(动态)', '市净率',
           '市销率', '市销率(TTM)', '股息率(%)', '股息率(TTM)(%)', '总股本(万股)', '流通股本(万股)',
           '总市值(万元)', '流通市值(万元)']
    stock_daily["date"]=stock_daily["date"].astype("str").astype("datetime64")
    stock_daily.set_index("date",inplace=True,drop=False)
    stock_daily["openinterest"]=0
    return stock_daily

def get_data_1(syboml,z0):
    stock=st.session_state.stock_daily[st.session_state.stock_daily["股票代码"]==syboml][["open","high","low","close","volume","openinterest"]]
    stock=pd.concat([stock,z0],axis=1).fillna(method="bfill").fillna(method="ffill")
#    stock=pd.concat([get_data_0("003002.SZ"),z1],axis=1).fillna(method="bfill").fillna(method="ffill")
    return stock[["open","high","low","close","volume","openinterest"]]

class my_strategy_date_2(bt.Strategy):
    #全局设定交易策略的参数
    cash_value={}
    params = (("sell_d",{}),("buy_d",{}))

    def __init__(self):
        # 初始化交易指令、买卖价格和手续费
        self.order = None

    def next(self):
        # 检查是否持仓 
        #print(str(self.datetime.date(0)))
        self.cash_value.update({str(self.datetime.date(0)):self.broker.getvalue()})
        if str(self.datetime.date(0)) in self.params.sell_d.keys(): # 没有持仓
            s_list=self.params.sell_d[str(self.datetime.date(0))]
            for i in s_list:
                self.order_target_percent(target=0,data=i)
        if str(self.datetime.date(0)) in self.params.buy_d.keys(): # 没有持仓
            s_list=self.params.buy_d[str(self.datetime.date(0))]
            for i in s_list:
                self.order_target_percent(target=0.9/len(s_list),data=i)
                

            
    def log(self, txt, dt=None):
        ''' 输出日志'''
        dt = dt or self.datas[0].datetime.date(0) # 拿现在的日期
        #st.write('%s, %s' % (dt.isoformat(), txt))

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            # Buy/Sell order submitted/accepted to/by broker - Nothing to do
            return

        # Check if an order has been completed
        # Attention: broker could reject order if not enough cash
        if order.status in [order.Completed, order.Canceled, order.Margin]:
            if order.isbuy():
                self.log(f"""买入{order.data._name}, 成交量{order.executed.size}，成交价{order.executed.price:.2f}""")
            elif order.issell():
                self.log(f"""卖出{order.data._name}, 成交量{order.executed.size}，成交价{order.executed.price:.2f}""")
            self.bar_executed = len(self)

        # Write down: no pending order
        self.order = None

def huice_run_num(start,end,sell_date,buy_date,stock_list,strategy):
    
    z1=pd.Series(range(0,len(st.session_state.stock_daily.date.unique())),index=st.session_state.stock_daily.date.unique()).sort_index()
    cerebro = bt.Cerebro()
    for i in stock_list:
        stock=get_data_1(i,z1)
        data = bt.feeds.PandasData(dataname=stock,fromdate=start,todate=end)           
        cerebro.adddata(data,name=i) 
        
    cerebro.addstrategy(strategy,sell_d=sell_date,buy_d=buy_date) 
    cerebro.broker.setcash(100000) 
    cerebro.broker.setcommission(commission=0.002) 


    st.write(start.date(),end.date())
    st.write('初始资金: %.2f' % cerebro.broker.getvalue())
    cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name = 'SharpeRatio')
    cerebro.addanalyzer(bt.analyzers.DrawDown, _name='DW')
    results = cerebro.run()
    strat = results[0]
    st.write('最终资金: %.2f' % cerebro.broker.getvalue())
    st.write('夏普比率:', strat.analyzers.SharpeRatio.get_analysis())
    st.write('回撤指标:', strat.analyzers.DW.get_analysis())
    
    return strategy.cash_value

def line_cash(x):
    option = {
      "xAxis": {
        "type": 'category',
        "data": list(x.keys())
      },
      "yAxis": {
        "type": 'value'
      },
      "series": [
        {
          "data": list(x.values()),
          "type": 'line'
        }
      ]
    };
    return option

conn=sqlite3.connect(r'F:\量化金融\stock_2018.db')

if 'stock_daily' not in st.session_state:
    st.session_state.stock_daily = read_hq()
    
if 'cw' not in st.session_state:
    st.session_state.cw = read_cw()

start=datetime(2018,2,22)
end=datetime(2023,2,10)

run1=st.button("run")
if run1:
    stock_list=["003002.SZ","003003.SZ","300001.SZ"]
    buy_date={"2020-09-22":["003002.SZ","003003.SZ"]}
    sell_date={"2023-02-02":["003002.SZ","003003.SZ"]}
    result=huice_run_num(start,end,sell_date,buy_date,stock_list,my_strategy_date_2)
    st_echarts(line_cash(result))